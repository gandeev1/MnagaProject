from django.urls import path
from . import views

urlpatterns = [
    path('', views.homePage, name='home'),  # Ensure you use name='home' for consistency
    path('login/', views.login_view, name='login'),  # Corrected the name here
    path('register/', views.register_view, name='register'),  # Added register path
]
